# Proyek Web Profil Kampus — Universitas Handayani

Proyek Akhir Mata Kuliah **Pemrograman Web** — TA 2025/2026 Genap

Website profil kampus statis dibangun murni dengan **HTML, CSS, dan JavaScript**,
menggunakan **jQuery** sebagai satu-satunya library eksternal (sesuai ketentuan
tugas: tidak boleh menggunakan template/framework/library lain).

---

## 1. Struktur Halaman

| # | Halaman | File |
|---|---------|------|
| 1 | Halaman Utama (Home) | `index.html` |
| 2 | Halaman Tentang (About) | `about.html` |
| 3 | Halaman Program Studi | `programs.html` |
| 4 | Halaman Berita & Acara | `news.html` |
| 5 | Halaman Galeri | `gallery.html` |
| 6 | Halaman Kontak | `contact.html` |
| 7 | Halaman Pendaftaran | `admission.html` |

```
site/
├── index.html
├── about.html
├── programs.html
├── news.html
├── gallery.html
├── contact.html
├── admission.html
├── css/
│   └── style.css
├── js/
│   └── script.js
└── images/          ← letakkan foto/video asli kampus di sini
```

## 2. Teknologi

- **HTML5** semantik di seluruh halaman.
- **CSS3** murni (custom properties/variables, grid, flexbox) — tanpa Bootstrap/Tailwind.
- **JavaScript + jQuery** (`js/script.js`) untuk:
  - menu navigasi responsif (mobile toggle),
  - highlight menu aktif otomatis,
  - accordion pada halaman Berita,
  - filter kategori + lightbox pada halaman Galeri,
  - validasi formulir pada halaman Kontak dan Pendaftaran.

## 3. Menjalankan secara lokal

Cukup buka `index.html` langsung di browser, atau jalankan server statis sederhana:

```bash
# Python
python -m http.server 8000
# lalu buka http://localhost:8000
```

## 4. Mengganti Konten Placeholder

- Gambar galeri saat ini berupa blok warna (placeholder) — ganti dengan foto/video
  asli kampus di `images/` lalu perbarui `gallery.html`.
- Data berita, profil rektor/dekan, alamat, dan kontak pada seluruh halaman bersifat
  contoh — sesuaikan dengan data kampus yang sebenarnya.

## 5. Panduan Penggunaan GitHub (Poin 8 Tugas)

Langkah-langkah agar proyek dikelola dengan baik menggunakan GitHub:

### a. Inisialisasi repository

```bash
cd site
git init
git add .
git commit -m "Initial commit: struktur dasar proyek web profil kampus"
```

### b. Beri nama repository sesuai ketentuan

Sesuai catatan tugas, nama proyek harus mengikuti format:

```
2025-2026_GENAP_NPM_NAMA
```

> **Ganti `NPM` dan `NAMA` dengan NPM dan nama Anda sendiri**, misalnya:
> `2025-2026_GENAP_31210001_AhmadRizki`

```bash
git remote add origin https://github.com/<username-anda>/2025-2026_GENAP_NPM_NAMA.git
git branch -M main
git push -u origin main
```

### c. Tambahkan email dosen sebagai kolaborator (wajib)

Sesuai catatan tugas, tambahkan email berikut sebagai kolaborator pada repository:

```
adnan@handayani.ac.id
```

Caranya: buka repository di GitHub → **Settings** → **Collaborators** →
**Add people** → masukkan email di atas → **Add**.

### d. Commit secara berkala

Lakukan commit setiap kali menyelesaikan bagian tertentu, dengan pesan yang jelas, misalnya:

```bash
git add .
git commit -m "Tambah halaman Program Studi"
git commit -m "Tambah validasi formulir pendaftaran"
git commit -m "Perbaikan tampilan responsif galeri"
git push
```

### e. Sebelum batas akhir (31 Juli 2026)

- Pastikan seluruh 7 halaman sudah ter-push ke branch `main`.
- Pastikan email kolaborator sudah ditambahkan.
- Pastikan nama repository sudah sesuai format `2025-2026_GENAP_NPM_NAMA`.

---

**Batas Akhir Pengumpulan:** 31 Juli 2026
