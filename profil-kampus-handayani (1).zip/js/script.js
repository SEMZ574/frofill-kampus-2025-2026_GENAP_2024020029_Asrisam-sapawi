/* =========================================================
   UNIVERSITAS HANDAYANI — script.js
   Menggunakan jQuery untuk seluruh interaksi (sesuai ketentuan
   tugas: tidak menggunakan framework/library eksternal lain).
   ========================================================= */
$(function () {

  /* ---------- 1. Tandai menu aktif sesuai halaman ---------- */
  var currentPage = window.location.pathname.split("/").pop() || "index.html";
  $(".main-nav a").each(function () {
    var href = $(this).attr("href");
    if (href === currentPage) $(this).addClass("active");
  });

  /* ---------- 2. Toggle menu mobile ---------- */
  $(".nav-toggle").on("click", function () {
    $(".main-nav").toggleClass("open");
    var expanded = $(".main-nav").hasClass("open");
    $(this).attr("aria-expanded", expanded);
  });
  // tutup menu saat salah satu link diklik (mobile)
  $(".main-nav a").on("click", function () {
    $(".main-nav").removeClass("open");
  });

  /* ---------- 3. Header shadow saat discroll ---------- */
  $(window).on("scroll", function () {
    $(".site-header").toggleClass("scrolled", $(window).scrollTop() > 8);
  });

  /* ---------- 4. Accordion berita/FAQ ---------- */
  $(".accordion-toggle").on("click", function () {
    var $panel = $(this).closest(".news-item, .faq-item").find(".accordion-panel");
    var isOpen = $panel.hasClass("open");
    $panel.toggleClass("open", !isOpen);
    $(this).attr("aria-expanded", !isOpen);
  });

  /* ---------- 5. Filter galeri ---------- */
  $(".filter-btn").on("click", function () {
    var filter = $(this).data("filter");
    $(".filter-btn").removeClass("active");
    $(this).addClass("active");

    if (filter === "all") {
      $(".gallery-item").removeClass("hidden");
    } else {
      $(".gallery-item").each(function () {
        var cat = $(this).data("category");
        $(this).toggleClass("hidden", cat !== filter);
      });
    }
  });

  /* ---------- 6. Lightbox galeri ---------- */
  $(".gallery-item").on("click", function () {
    var title = $(this).data("title") || "Galeri Kampus";
    var desc = $(this).data("desc") || "";
    var color = $(this).css("background-color");

    $("#lightbox .lightbox-media").css("background", color).text($(this).find(".g-icon").text());
    $("#lightbox .lightbox-title").text(title);
    $("#lightbox .lightbox-desc").text(desc);
    $("#lightbox").addClass("open").attr("aria-hidden", "false");
    $("body").css("overflow", "hidden");
  });
  $(".lightbox-close, .lightbox").on("click", function (e) {
    if (e.target === this) {
      $("#lightbox").removeClass("open").attr("aria-hidden", "true");
      $("body").css("overflow", "");
    }
  });
  $(document).on("keyup", function (e) {
    if (e.key === "Escape") {
      $("#lightbox").removeClass("open").attr("aria-hidden", "true");
      $("body").css("overflow", "");
    }
  });

  /* ---------- 7. Validasi form (Kontak & Pendaftaran) ---------- */
  function validateField($field) {
    var $wrap = $field.closest(".field");
    var val = $.trim($field.val());
    var valid = true;

    if ($field.prop("required") && val === "") valid = false;
    if ($field.attr("type") === "email" && val !== "") {
      var re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!re.test(val)) valid = false;
    }
    if ($field.attr("type") === "tel" && val !== "") {
      var reTel = /^[0-9+\-\s]{8,15}$/;
      if (!reTel.test(val)) valid = false;
    }

    $wrap.toggleClass("invalid", !valid);
    return valid;
  }

  $(".site-form").each(function () {
    var $form = $(this);

    $form.find("input, select, textarea").on("blur", function () {
      validateField($(this));
    });

    $form.on("submit", function (e) {
      e.preventDefault();
      var allValid = true;

      $form.find("input, select, textarea").each(function () {
        if (!validateField($(this))) allValid = false;
      });

      if (allValid) {
        $form.find(".form-success").addClass("show");
        $form[0].reset();
        $form.find(".field").removeClass("invalid");
        $("html, body").animate(
          { scrollTop: $form.find(".form-success").offset().top - 120 },
          300
        );
      } else {
        var $firstInvalid = $form.find(".field.invalid").first();
        if ($firstInvalid.length) {
          $("html, body").animate({ scrollTop: $firstInvalid.offset().top - 140 }, 300);
        }
      }
    });
  });

  /* ---------- 8. Tahun berjalan di footer ---------- */
  $(".current-year").text(new Date().getFullYear());

});
